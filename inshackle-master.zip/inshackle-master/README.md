# Inshackle v1.0
## Inshackle v1.0 github.com/xd20111/inshackle
## IG : instagram.com/xd_20111
## Website: www.yourhacker.in
## Author: github.com/thelinuxchoice/inshackle
## Author IG: instagram.com/linux_choice
### if you want to copy this code Please give Author credits {i mean dont forget Author credit}, nerd! Please read the License 

Instagram hacks: Track unfollowers, Increase your followers, Download Stories, etc

### Features:
#### Unfollow Tracker
#### Increase Followers
#### Download: Stories, Saved Content, Following/followers list, Profile Info
#### Unfollow all your following

![ins](https://user-images.githubusercontent.com/34893261/53686880-d50f6000-3d0b-11e9-8c42-cab1ad30b24e.png)

### Usage:
```
git clone https://github.com/xd20111/inshackle
cd inshackle
bash inshackle.sh
```

### Happy Hacking #xd20111
